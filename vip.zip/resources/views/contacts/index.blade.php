<x-app-layout>
    
    <div class="container py-12">
        @livewire('contact-component'){{-- componente don se crea la vista del formulario de contacto --}}
    </div>
    
</x-app-layout>